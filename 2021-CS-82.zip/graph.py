import os
import networkx as nx
import matplotlib.pyplot as plt

def construct_graph(file_path):
    G = nx.DiGraph()
    with open(file_path, 'r', encoding='utf-8') as file:
        words = file.read().split()
        for i in range(len(words) - 1):
            current_word = words[i]
            next_word = words[i + 1]
            if G.has_edge(current_word, next_word):
                print(G[current_word][next_word])
                G[current_word][next_word]['weight'] += 1
            else:
                G.add_edge(current_word, next_word, weight=1)
    return G
def print_adjacency_matrix(G):
    nodes = sorted(G.nodes())
    print("\t" + "\t".join(nodes))
    for node1 in nodes:
        row = [str(G[node1].get(node2, {'weight': 0})['weight']) for node2 in nodes]
        print(f"{node1}\t{'\t'.join(row)}")
        
def print_adjacency_list(G):
    for node in G.nodes():
        neighbors = list(G.neighbors(node))
        if neighbors:
            print(f"{node}: {', '.join(neighbors)}")
        else:
            print(f"{node}:")          

def visualize_graph(G, file_path):
    plt.figure(figsize=(10, 10))
    pos = nx.spring_layout(G)
    nx.draw(G, pos, with_labels=True, node_color='skyblue', node_size=10, edge_color='black', linewidths=1, arrows=True, arrowsize=20)
    labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    plt.title(f'Directed Graph of Words in {os.path.basename(file_path)}')
    plt.show()

def visualize_preprocessed_files(folder):
    graphs = []
    for file_name in os.listdir(folder):
        if file_name.startswith('preprocessed_') and file_name.endswith('.txt'):
            file_path = os.path.join(folder, file_name)
            G = construct_graph(file_path)
            graphs.append(G)
            print(G)
            # print_adjacency_matrix(G)
            # print_adjacency_list(G)
            # visualize_graph(G, file_path)
    return graphs

# Specify the folder where the preprocessed files are stored
preprocess_files_folder = '.'

def find_common_subgraph(graphs):
    if len(graphs) < 2:
        print("At least two graphs are required to find a common subgraph.")
        return None

    common_subgraph = graphs[0].copy()
    for graph in graphs[1:]:
        common_subgraph = nx.compose(common_subgraph, graph)

    # Remove nodes that are not common across all graphs
    for node in list(common_subgraph.nodes()):
        if not all(node in graph for graph in graphs):
            common_subgraph.remove_node(node)

    return common_subgraph

graphs=visualize_preprocessed_files(preprocess_files_folder)
# Find common subgraph
common_subgraph = find_common_subgraph(graphs)

if common_subgraph is not None:
    print("Common subgraph found:")
    print_adjacency_list(common_subgraph)
    visualize_graph(common_subgraph, "Common Subgraph")
else:
    print("No common subgraph found among the graphs.")

# Visualize preprocessed files as directed graphs
